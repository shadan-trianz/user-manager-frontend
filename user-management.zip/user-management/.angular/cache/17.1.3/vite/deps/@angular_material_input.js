import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-WIXDTUYB.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-NCXVFZ2P.js";
import "./chunk-EAJ7XUP4.js";
import "./chunk-JAVP5ZRK.js";
import "./chunk-XCTDRCSH.js";
import "./chunk-IGU6QSFS.js";
import "./chunk-Z34T3VMF.js";
import "./chunk-SXIXOCJ4.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
